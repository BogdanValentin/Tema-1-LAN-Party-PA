#pragma once

#include <stdlib.h>
#include <stdio.h>

// Prints an error message and exits the program with code 1.
void mallocError();

// Prints an error message and exits the program with code 1.
void fileError(char *fileName);